package com.aviation.util;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.aviation.model.Flight;


@Component
public class FlightDetailsUtil {

	public List<Flight> getAllFlightDetails() {
		List<Flight> flightList = new ArrayList<>();
		Flight flight = new Flight();
		
		flight.setFlightID(1001L);
		flight.setUuid(UUID.randomUUID().toString());
		flight.setTakeoff_timestamp(LocalDateTime.now());
		flight.setLanding_timestamp(LocalDateTime.now());
		flight.setDeparture_from("BBSR");
		flight.setArrival_at("HYD");
		flight.setFlight_ticket_price(3056.0f);
		flightList.add(flight);
		
		return flightList;
	}
	
}
