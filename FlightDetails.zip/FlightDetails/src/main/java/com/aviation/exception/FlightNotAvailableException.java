package com.aviation.exception;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class FlightNotAvailableException {
	
	private String errorCode = HttpStatus.NOT_FOUND.toString();
	private String message = "No Flight Available";

	@Override
	public String toString() {
		return "{\n"
				+ "\terrorCode: " + errorCode + ","
				+ "\n\tmessage: " + message + "\n"
				+ "}";
	}
	
	public String getMessage() {
		return toString();
	}
	
}
