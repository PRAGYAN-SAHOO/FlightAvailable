package com.aviation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aviation.exception.FlightNotAvailableException;
import com.aviation.model.Flight;
import com.aviation.service.FlightService;


@RestController
@RequestMapping("/flights/")
public class FlightRestController {
	
	@Autowired
	private FlightService flightService;
	
	@Autowired
	private FlightNotAvailableException flightNotAvailableException;

	@GetMapping("/cheapest_flights/{depature_city}/{arrival_city}")
	public ResponseEntity<?> getCheapestFlight(@PathVariable("depature_city") String depature_city, @PathVariable("arrival_city") String arrival_city) {
		List<Flight> flightList = flightService.getCheapestFlight(depature_city, arrival_city);
		if (flightList != null) {
			return new ResponseEntity<>(flightList, HttpStatus.OK);
		}
		else {
			//return new ResponseEntity<>(throw new FlightNotAvailableException("No flights are available"), HttpStatus.EXPECTATION_FAILED);
			
		return new ResponseEntity<>(flightNotAvailableException.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
}
