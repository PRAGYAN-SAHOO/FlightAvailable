package com.aviation.model;

import java.time.LocalDateTime;


public class Flight {
	private Long flightID;
	private String uuid;
	private LocalDateTime takeoff_timestamp;
	private LocalDateTime landing_timestamp;
	private String departure_from;
	private String arrival_at; 
	private Float flight_ticket_price;
	public Long getFlightID() {
		return flightID;
	}
	public void setFlightID(Long flightID) {
		this.flightID = flightID;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public LocalDateTime getTakeoff_timestamp() {
		return takeoff_timestamp;
	}
	public void setTakeoff_timestamp(LocalDateTime takeoff_timestamp) {
		this.takeoff_timestamp = takeoff_timestamp;
	}
	public LocalDateTime getLanding_timestamp() {
		return landing_timestamp;
	}
	public void setLanding_timestamp(LocalDateTime landing_timestamp) {
		this.landing_timestamp = landing_timestamp;
	}
	public String getDeparture_from() {
		return departure_from;
	}
	public void setDeparture_from(String departure_from) {
		this.departure_from = departure_from;
	}
	public String getArrival_at() {
		return arrival_at;
	}
	public void setArrival_at(String arrival_at) {
		this.arrival_at = arrival_at;
	}
	public Float getFlight_ticket_price() {
		return flight_ticket_price;
	}
	public void setFlight_ticket_price(Float flight_ticket_price) {
		this.flight_ticket_price = flight_ticket_price;
	}
	@Override
	public String toString() {
		return "Flight [flightID=" + flightID + ", uuid=" + uuid + ", takeoff_timestamp=" + takeoff_timestamp
				+ ", landing_timestamp=" + landing_timestamp + ", departure_from=" + departure_from + ", arrival_at="
				+ arrival_at + ", flight_ticket_price=" + flight_ticket_price + "]";
	} 
	
	
}
