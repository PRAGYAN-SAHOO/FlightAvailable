package com.aviation.service;

import java.util.List;

import com.aviation.model.Flight;


public interface FlightService {

	public List<Flight> getCheapestFlight(String depature_city, String arrival_city);
	
}
