package com.aviation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aviation.model.Flight;
import com.aviation.util.FlightDetailsUtil;


@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	private FlightDetailsUtil detailsUtil;
	
	@Override
	public List<Flight> getCheapestFlight(String depature_city, String arrival_city) {
		return detailsUtil.getAllFlightDetails();
	}

}
